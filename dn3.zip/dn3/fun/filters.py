import os
import numpy as np
from scipy.fft import fft, ifft
from scipy.signal import butter, filtfilt, firwin, lfilter

FREQ=1000
NIPAS=10
VIPAS=40
TAPS=101
#INPUTF="fun" če imamo datoteke kje drugje

def fourier(signal, freq=FREQ, lc=NIPAS, hc=VIPAS):
    """Poda inverz Fourierove transformacije"""
    # Fourierjeva transformacija signala
    freqs = np.fft.fftfreq(len(signal), d=1/freq)
    fft_signal = fft(signal)

    # Bandpass filtriranje v frekvenčni domeni
    fft_signal[(freqs < lc) | (freqs > hc)] = 0

    return np.real(ifft(fft_signal))


def butterworh(signal, freq=FREQ, lc=NIPAS, hc=VIPAS, red=4):

    nyq = 0.5 * freq  # Nyquist frekvenca
    low = lc / nyq
    high = hc / nyq
    b, a = butter(red, [low, high], btype='band')
    return filtfilt(b, a, signal)  # dvosmerno filtriranje (brez faznega zamika)


def fir(signal, fs=FREQ, lc=NIPAS, hc=VIPAS, taps=TAPS):
    
    # Izračun FIR koeficientov
    fir_coeffs = firwin(taps, [lc, hc], pass_zero=False, fs=fs)

    return lfilter(fir_coeffs, 1.0, signal)