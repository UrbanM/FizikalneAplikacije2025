import matplotlib.pyplot as plt
import numpy as np
import os

def grafi_npy():
    for f in os.listdir("fun"):
        if f.endswith(".npy"):
            fpa=os.path.join("fun",f)
            signal = np.load(fpa)
            time = signal['Time (s)']  # Use exact column name from your data
            voltage = signal['Input 1 (V)']  # Match capitalization and spaces

            # Create the plot
            plt.figure(figsize=(12, 5))
            plt.plot(time, voltage, linewidth=0.8)
            plt.title('$U(t)$')
            plt.xlabel('$t [s]')
            plt.ylabel('$U$ [mV]')
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(f"{fpa}.png",dpi=200)
            plt.show()

def plot_filter_comparison():
    
    parent_dir = os.path.dirname(os.path.abspath("fun"))
    filtered_dir = os.path.join(parent_dir, "filtered_data")
    os.makedirs(filtered_dir, exist_ok=True)

    for file in os.listdir("fun"):
        if file.endswith(".npy") and not file.startswith(("fourier_", "butterworth_", "fir_")):
            # Load original data
            orig_path = os.path.join("fun", file)
            orig_data = np.load(orig_path)
            time = orig_data['Time (s)']
            orig_signal = orig_data['Input 1 (V)']
            
            # Load filtered data
            base_name = os.path.splitext(file)[0]
            fourier_path = os.path.join(filtered_dir, f"fourier_{base_name}.npy")
            butterworth_path = os.path.join(filtered_dir, f"butterworth_{base_name}.npy")
            fir_path = os.path.join(filtered_dir, f"fir_{base_name}.npy")
            
            fourier_signal = np.load(fourier_path)
            butterworth_signal = np.load(butterworth_path)
            fir_signal = np.load(fir_path)

            plt.figure(figsize=(15, 10))
            
            # Plot original vs Fourier
            plt.subplot(3, 1, 1)
            plt.plot(time, orig_signal, label='Original', alpha=0.7, linewidth=0.8)
            plt.plot(time, fourier_signal, label='Fourier Filtered', linewidth=1.2)
            plt.title(f'Primerjava signalov: {file}')
            plt.ylabel('$U$ [mV]')
            plt.grid(True)
            plt.legend()
            plt.xlim(0, 20)
            
            # Plot original vs Butterworth
            plt.subplot(3, 1, 2)
            plt.plot(time, orig_signal, alpha=0.7, linewidth=0.8)
            plt.plot(time, butterworth_signal, label='Butterworth Filtered', linewidth=1.2)
            plt.ylabel('$U$ [mV]')
            plt.grid(True)
            plt.legend()
            plt.xlim(0, 20)
            
            # Plot original vs FIR
            plt.subplot(3, 1, 3)
            plt.plot(time, orig_signal, alpha=0.7, linewidth=0.8)
            plt.plot(time, fir_signal, label='FIR Filtered', linewidth=1.2)
            plt.xlabel('$t$ [s]')
            plt.ylabel('$U$ [mV]')
            plt.grid(True)
            plt.legend()
            plt.xlim(0, 20)
            
            plt.tight_layout()
            
            # Save to parent directory
            save_path = os.path.join(parent_dir, f"filter_comparison_{base_name}.png")
            plt.savefig(save_path, dpi=300)
            plt.close()