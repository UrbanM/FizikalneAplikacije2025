# -*- coding: utf-8 -*-
"""
Modul za analizo srčnega utripa (BPM) in variabilnosti srčnega utripa (HRV)
za fiksne faze (pred-HVL, HVL, po-HVL) iz predhodno filtriranih EKG podatkov.

Predpostavlja strukturo poskusa:
- 0-120s: Normalno dihanje (Pred_HVL)
- 120~200s: Hiperventilacija (HVL)
- 180s - konec: Normalno dihanje (Po_HVL)
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import neurokit2 as nk
import traceback

# --- Pomožne funkcije ---

def plot_phase_transition(signal, pre_indices_tuple, hv_indices_tuple, post_indices_tuple, output_dir, filename, fs=1000):
    """Izriše EKG signal z označenimi fiksnimi fazami."""
    # Ta funkcija samo riše glede na podane indekse
    try:
        base_filename = os.path.basename(filename)
        plt.figure(figsize=(15, 6))
        time_vector = np.arange(len(signal)) / fs

        plt.plot(time_vector, signal, label='EKG Signal (filtriran)', alpha=0.8, color='black', linewidth=0.7)

        start_pre, stop_pre, _ = pre_indices_tuple
        start_hv, stop_hv, _ = hv_indices_tuple
        start_post, stop_post, _ = post_indices_tuple

        def format_time(index):
             return f"{time_vector[index]:.1f}s" if 0 <= index < len(time_vector) else "N/A"

        # Plot regions using the passed indices
        if stop_pre > start_pre and stop_pre <= len(time_vector):
             t_start, t_stop = format_time(start_pre), format_time(stop_pre - 1)
             plt.axvspan(time_vector[start_pre], time_vector[stop_pre - 1], color='green', alpha=0.2, label=f'Pred_HVL (0-120s; {t_start}-{t_stop})')
        if stop_hv > start_hv and stop_hv <= len(time_vector):
             t_start, t_stop = format_time(start_hv), format_time(stop_hv - 1)
             plt.axvspan(time_vector[start_hv], time_vector[stop_hv - 1], color='red', alpha=0.2, label=f'HVL (120-180s; {t_start}-{t_stop})')
        # Adjust post-HVL label slightly if needed
        if stop_post > start_post and start_post < len(time_vector): # Check start_post validity
            t_start, t_stop = format_time(start_post), format_time(len(time_vector) - 1)
            plt.axvspan(time_vector[start_post], time_vector[-1], color='blue', alpha=0.2, label=f'Po_HVL (180s+; {t_start}-{t_stop})')


        plt.xlabel('$t$ [s]')
        plt.ylabel('$V$ [mV] ali Amplituda')
        plt.title(f'Fiksne faze: {base_filename}')
        plt.legend(loc='upper right')
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.tight_layout()

        plot_filename = f"phase_detection_{base_filename[:-4]}.png"
        plt.savefig(os.path.join(output_dir, plot_filename))
        print(f"[HRVBPM] Graf faz shranjen v: {plot_filename}")
        plt.close()
    except IndexError:
         print(f"[HRVBPM] Napaka pri indeksiranju med risanjem grafa za {base_filename}. Faza je morda prekratka ali prazna.")
         if plt.gcf().get_axes(): plt.close()
    except Exception as e:
        print(f"[HRVBPM] Napaka pri izrisu grafa faz za {base_filename}: {e}")
        if plt.gcf().get_axes(): plt.close()

def save_results(results, output_dir, filename):
    """Shrani izračunane metrike v tekstovno datoteko."""
    # Ta funkcija ostane nespremenjena
    base_filename = os.path.basename(filename)
    try:
        results_filename = f"results_{base_filename[:-4]}.txt"
        filepath = os.path.join(output_dir, results_filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"Rezultati analize za datoteko: {base_filename}\n")
            f.write("Faze definirane s fiksnimi časi (0-120s, 120~200s, 200s+)\n")
            f.write("=" * 40 + "\n")
            if not results:
                f.write("Ni rezultatov za shranjevanje.\n")
                return

            for phase, metrics in results.items():
                f.write(f"\nFaza: {phase}\n")
                f.write("-" * 20 + "\n")
                if metrics:
                    all_na = all(v is None or np.isnan(v) for v in metrics.values())
                    if all_na:
                         f.write("Vrednosti ni bilo mogoče izračunati (premalo podatkov ali napaka).\n")
                    else:
                        for metric, value in metrics.items():
                            if value is not None and not np.isnan(value):
                                f.write(f"  {metric}: {value:.2f}\n")
                            else:
                                f.write(f"  {metric}: N/A\n")
                else:
                    f.write("Ni izračunanih vrednosti.\n")
            f.write("\n" + "=" * 40 + "\n")
        print(f"[HRVBPM] Rezultati shranjeni v: {results_filename}")
    except Exception as e:
        print(f"[HRVBPM] Napaka pri shranjevanju rezultatov za {base_filename}: {e}")


# --- Glavna funkcija modula ---

def hrvbpm(fs=1000):
    """
    Glavna funkcija za zagon analize HRV in BPM za fiksne faze.

    Poišče mape 'filtered_data' in 'Phase_Analysis' relativno na mapo,
    ki vsebuje mapo 'fun'.
    """
    try:
        # Določi poti (ostaja enako)
        try:
             module_path = os.path.abspath(__file__)
             fun_dir = os.path.dirname(module_path)
             parent_dir = os.path.dirname(fun_dir)
        except NameError:
             print("[HRVBPM] Opozorilo: __file__ ni definiran. Uporabljam CWD za določanje poti.")
             fun_dir_abspath = os.path.abspath("fun")
             parent_dir = os.path.dirname(fun_dir_abspath)

        filtered_dir = os.path.join(parent_dir, "filtered_data")
        output_dir = os.path.join(parent_dir, "Phase_Analysis")

        print(f"\n--- [HRVBPM Modul - SIMPLIFIED] Začenjam analizo za fiksne faze ---")
        print(f"--- Pričakujem filtrirane podatke v: {filtered_dir}")
        print(f"--- Rezultate bom shranil v: {output_dir}")

        if not os.path.isdir(filtered_dir):
             print(f"NAPAKA: Mapa s filtriranimi podatki '{filtered_dir}' ne obstaja ali ni mapa.")
             return

        os.makedirs(output_dir, exist_ok=True)
        _process_all_files_fixed_phases(filtered_dir, output_dir, fs) # Kliči poenostavljeno funkcijo

    except Exception as e:
        print(f"[HRVBPM] KRITIČNA NAPAKA v funkciji hrvbpm: {e}")
        traceback.print_exc()

def _process_all_files_fixed_phases(filtered_dir, output_dir, fs):
    """Obdela datoteke z uporabo fiksnih časovnih mej za faze."""
    processed_files_count = 0
    error_files_count = 0
    files_to_process = [f for f in os.listdir(filtered_dir) if f.endswith(".npy")]

    if not files_to_process:
        print("[HRVBPM] Opozorilo: V mapi 'filtered_data' ni najdenih .npy datotek.")
        return

    # Fiksni časi v sekundah
    T_START_HV_SEC = 120
    T_END_HV_SEC = 200

    for file in files_to_process:
        file_path = os.path.join(filtered_dir, file)
        print(f"\n[HRVBPM] Obdelujem datoteko: {file}")
        try:
            # Naloži podatke
            data = np.load(file_path, allow_pickle=True)
            signal = None
            if data.dtype.names and 'Input 1 (V)' in data.dtype.names:
                signal = data['Input 1 (V)']
            elif isinstance(data, np.ndarray):
                signal = data
            else:
                print(f"[HRVBPM] Napaka: Neznana struktura podatkov v {file}. Preskakujem.")
                error_files_count += 1
                continue

            signal_len_samples = len(signal)
            if signal is None or signal_len_samples < fs * 5: # Potrebujemo vsaj malo signala
                print(f"[HRVBPM] Napaka: Signal v {file} je prekratek ali neveljaven. Preskakujem.")
                error_files_count += 1
                continue

            # --- 1. Določi fiksne meje v vzorcih ---
            sample_start_hv = int(T_START_HV_SEC * fs)
            sample_end_hv = int(T_END_HV_SEC * fs)

            # Prilagodi meje, če je signal krajši od pričakovanega
            sample_start_hv = min(sample_start_hv, signal_len_samples)
            sample_end_hv = min(sample_end_hv, signal_len_samples)
            # Zagotovi, da konec ni pred začetkom
            if sample_end_hv < sample_start_hv:
                 sample_end_hv = sample_start_hv

            # Ustvari slice objekte in indekse
            pre_slice = slice(0, sample_start_hv)
            hv_slice = slice(sample_start_hv, sample_end_hv)
            post_slice = slice(sample_end_hv, signal_len_samples) # Do konca dejanskega signala

            pre_indices = pre_slice.indices(signal_len_samples)
            hv_indices = hv_slice.indices(signal_len_samples)
            post_indices = post_slice.indices(signal_len_samples)

            phases = {
                "Pred_HVL (0-120s)": signal[pre_slice],
                "HVL (120-180s)": signal[hv_slice],
                "Po_HVL (180s+)": signal[post_slice]
            }
            print(f"[HRVBPM] Uporabljam fiksne faze: Pred={pre_indices}, HVL={hv_indices}, Po={post_indices}")


            # --- 2. Analiziraj vsako fazo (HRV/BPM) ---
            results = {}
            print("[HRVBPM] Računam metrike za faze:")
            for phase_name, phase_signal in phases.items():
                print(f"Faza: {phase_name} (dolžina: {len(phase_signal)} vzorcev)")
                results[phase_name] = {"mean_hr": np.nan, "hrv_sdnn": np.nan, "hrv_rmssd": np.nan}

                # Preskoči analizo, če je faza prekratka
                # Potrebujemo vsaj 3 R-vrhove za SDNN/RMSSD => vsaj cca 2-3 sekunde?
                if len(phase_signal) < fs * 3:
                    print("Faza prekratka za zanesljivo HRV analizo.")
                    continue

                try:
                    # Najdi R vrhove v signalu faze
                    # Predpostavlja se, da je signal že filtriran
                    _, rpeaks = nk.ecg_peaks(phase_signal, sampling_rate=fs)
                    rpeak_indices = rpeaks["ECG_R_Peaks"]

                    # Potrebujemo vsaj 3 R vrhove za izračun SDNN in RMSSD
                    if len(rpeak_indices) >= 3:
                        # Izračunaj RR intervale v ms
                        rr = np.diff(rpeak_indices) / fs * 1000
                        rr = rr[rr > 0] # Upoštevaj samo pozitivne RR intervale

                        if len(rr) > 0:
                             # Izračunaj povprečni HR
                             rr_mean = np.mean(rr)
                             if rr_mean > 0:
                                 results[phase_name]["mean_hr"] = 60000.0 / rr_mean

                        if len(rr) >= 2: # Potrebujemo vsaj 2 RR intervala za SDNN
                            # Izračunaj SDNN
                            results[phase_name]["hrv_sdnn"] = np.std(rr, ddof=1) # ddof=1 za vzorčni std dev

                        # Za RMSSD potrebujemo vsaj 2 RR intervala -> 1 razliko med njimi
                        if len(rr) >= 2:
                            rr_diff = np.diff(rr)
                            if len(rr_diff) >= 1:
                                # Izračunaj RMSSD
                                results[phase_name]["hrv_rmssd"] = np.sqrt(np.mean(np.square(rr_diff)))

                        # Izpis rezultatov za fazo
                        hr_str = f"{results[phase_name]['mean_hr']:.2f}" if not np.isnan(results[phase_name]['mean_hr']) else "N/A"
                        sdnn_str = f"{results[phase_name]['hrv_sdnn']:.2f}" if not np.isnan(results[phase_name]['hrv_sdnn']) else "N/A"
                        rmssd_str = f"{results[phase_name]['hrv_rmssd']:.2f}" if not np.isnan(results[phase_name]['hrv_rmssd']) else "N/A"
                        print(f"Izračunano: HR={hr_str}, SDNN={sdnn_str}, RMSSD={rmssd_str}")

                    else:
                        print(f"Premalo R vrhov ({len(rpeak_indices)}) v fazi za HRV analizo.")

                except Exception as phase_e:
                    print(f"[HRVBPM] Napaka pri HRV analizi faze '{phase_name}': {phase_e}")


            # --- 3. Shrani in vizualiziraj ---
            plot_phase_transition(signal, pre_indices, hv_indices, post_indices, output_dir, file, fs=fs)
            save_results(results, output_dir, file)
            processed_files_count += 1

        except FileNotFoundError:
             print(f"[HRVBPM] Napaka: Datoteka ni najdena {file_path}. Preskakujem.")
             error_files_count += 1
             continue
        except Exception as e:
            print(f"[HRVBPM] Nepričakovana napaka pri obdelavi {file}: {str(e)}")
            traceback.print_exc()
            error_files_count += 1
            continue

    print(f"\n--- [HRVBPM] Analiza faz končana. Obdelanih {processed_files_count} datotek, napak: {error_files_count}. ---")
