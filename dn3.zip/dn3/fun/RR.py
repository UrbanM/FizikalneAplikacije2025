import neurokit2 as nk
import numpy as np
import matplotlib.pyplot as plt
import os

def RRpd():
    parent_dir = os.path.dirname(os.path.abspath("fun"))
    filtered_dir = os.path.join(parent_dir, "filtered_data")
    output_dir = os.path.join(parent_dir, "RRints")
    fs = 1000  
    window = (-600, 600)  

    def detect_r_peaks(signal):
        _, rpeaks = nk.ecg_peaks(signal, sampling_rate=fs)
        peaks = rpeaks["ECG_R_Peaks"]
        
        
        if len(peaks) > 1:
            rr = np.diff(peaks)/fs*1000
            valid = (rr > 300) & (rr < 1200)
            return peaks[np.concatenate([valid, [True]])]
        return peaks

    def average_ecg(signal, r_peaks):
        
        pre = int(abs(window[0]) * fs) // 1000
        post = int(window[1] * fs) // 1000
        
        beats = []
        for peak in r_peaks:
            start = peak - pre
            end = peak + post
            if start >= 0 and end <= len(signal):
                beats.append(signal[start:end])
        
       
        if not beats:
            raise ValueError("Ni ustreznega pulza za analizo")
        
       
        max_len = max(len(b) for b in beats)
        aligned = [
            np.interp(np.linspace(0, 1, max_len),
                    np.linspace(0, 1, len(b)), b)
            for b in beats
        ]
        return np.mean(aligned, axis=0)

    os.makedirs(output_dir, exist_ok=True)

    for file in os.listdir(filtered_dir):
        if not file.endswith(".npy"):
            continue
            
        file_path = os.path.join(filtered_dir, file)
        try:
            data = np.load(file_path)
            signal = data['Input 1 (V)'] if data.dtype.names else data
            
            r_peaks = detect_r_peaks(signal)
            
            if len(r_peaks) < 5:
                print(f"Preskakujem {file}: {len(r_peaks)} vrhove")
                continue
                
            avg_ecg = average_ecg(signal, r_peaks)
            
            
            np.save(os.path.join(output_dir, f"avg_ecg_{file}"), avg_ecg)

            
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
            time = np.arange(len(signal)) / fs
            
            
            avg_time = np.linspace(window[0], window[1], len(avg_ecg))
            ax1.plot(avg_time, avg_ecg)
            ax1.set_title(f"Povprečen EKG: {file}")
            
           
            ax2.plot(time, signal, label='Signal')
            ax2.plot(time[r_peaks], signal[r_peaks], 'rx', markersize=8)
            ax2.set_xlim(0.3, 50)  
            ax2.set_title("R-vrhovi")
            
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, f"validation_{file[:-4]}.png"))
            plt.close()

        except Exception as e:
            print(f"Napaka procesiranja {file}: {str(e)}")