def wilcoxon():
    import numpy as np
    from scipy.stats import wilcoxon

    # Sample data (paired measurements)
    case_1 = np.array([10, 12, 9, 15, 14])
    case_2 = np.array([8, 11, 7, 13, 10])

    # Perform Wilcoxon signed-rank test
    stat, p = wilcoxon(case_1, case_2)

    print(f"Wilcoxon statistic: {stat}")
    print(f"P-value: {p}")

    # Interpretation
    alpha = 0.05
    if p < alpha:
        print("Significant difference (reject H0)")
    else:
        print("No significant difference (fail to reject H0)")
    return

def paired_t_test():
    import numpy as np
    from scipy.stats import ttest_rel

    # Sample data (paired measurements)
    case_1 = np.array([10, 12, 9, 15, 14])
    case_2 = np.array([8, 11, 7, 13, 10])

    # Perform paired t-test
    stat, p = ttest_rel(case_1, case_2)

    print(f"Paired t-test statistic: {stat:.4f}")
    print(f"P-value: {p:.4f}")

    # Interpretation
    alpha = 0.05
    if p < alpha:
        print("Significant difference (reject H0)")
    else:
        print("No significant difference (fail to reject H0)")
    return