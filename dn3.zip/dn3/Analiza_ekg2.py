#DN3
# Nekoliko neoptimalen pristop:
#   - zagotoviti je treba ustrezno strukturo map in datotek.
#   - Pristop je tak, ker sem moral majprej ugotoviti kakšna je sploh oblika npy datoteke
#   - Ko sem to poštudiral s spodnjimi funkcijami, sem šel v novo datoteko in spisal kodo za izris
#   - Na točki, kjer sem začel primerjati različne filtre, ki sem jih napisal nekoliko po svoje, sem ugotovil, da bi se dalo kodo zoptimizirati, ker so same enake strukture
#   - ampak, ker kode ne bo uporabljal nihče drug kot jaz, sem se s tem sprijaznil
#   - Sedaj je v stanju, kjer je treba imeti datoteke: testi.py, filters.py in izris.py v mapi "fun",
#       - Analiza_ekg2.py v mapi, ki vsebuje mapo "fun",
#       - V mapi "fun" morajo biti vse tri datoteke .npy,
#       - program ustvari 9 datotek (3 za vsak filter) za primerjavo filtrov in jih shrani v mapo "filtered_data",
#       - iz teh 9 datotek prebere podatke (so še vedno .npy) in nariše primerjavo (zagotoviti je treba, da bere te datoteke iz "filtered_data" mape)
#       - nato: 2. analiza vrhov R-R, kot predlagano; 3. bpm_HRV izračun; 4. namerno preskočim, ker smo ugotovili, da se ga ne da izvesti učunkovito

# Navodilo:
# 1. Časovne vrste najprej filtrirajte (bandpass filter; glej tri primere filtriranja v datoteki "Filters.py", izberite enega);
# 2. Izračunajte povprečno časovno vrsto elektrokardiograma, predlagam, da povprečite prek R vrhov;
# 3. Izračunajte povprečni srčni utrip ter variabilnost srčnega utripa med tremi stanji (1. normalno stanje pred hiperventiliranjem, 2. hiperventiliranje, ter 3. stanje po hiperventiliranju)
# 4. Poglejte ali obstaja statistična razlika med prvim in drugim stanjem za povprečni srčni utrip in HRV; uporabi wilcoxonov test (glej primer v datoteki "Testi.py"). Ta test mogoče ne bo deloval, ker imamo samo 3 meritve, vendar poskusite.

from fun import filters, izris, RR, HRVBPM
import numpy as np
import os

#---------------------ANALIZA .npy DATOTEK-----------#
n=0 #števec ustreznih fajlov (da vidim, če jih berem prav)
for fn in os.listdir("fun"):
    if fn.endswith(".npy"):
        n+=1
        fp=os.path.join("fun",fn)
print(f"Našel sem n={n} ustrezih datotek!\nObdelujem ...")

# Da vidim kake dimenzije je npy file
for file in os.listdir("fun"):
    if file.endswith(".npy"):
        fpa=os.path.join("fun",file)
        data = np.load(fpa)
        print(f"File: {file}")
        print(f"Shape: {data.shape}")
        print(f"Dimensions: {data.ndim}")
        print("-" * 40)

#--------------izris_npy------------DEBUG (preverim ali prav berem)
izris.grafi_npy()
#----------------------------------DEBUG

#--------PRIMERJAVA RAZLIČNIH FILTROV-------#
for file in os.listdir("fun"):
    if file.endswith(".npy"):
        fpa=os.path.join("fun",file)
        data=np.load(fpa)
        signal=data["Input 1 (V)"]
        ffur=filters.fourier(signal)
        fbut=filters.butterworh(signal)
        ffir=filters.fir(signal)

        np.save(f"filtered_data\\fourier_{file}", ffur)
        np.save(f"filtered_data\\butterworth_{file}", fbut)
        np.save(f"filtered_data\\fir_{file}", ffir)
#-----primerjava------------ (primerjam vse tri filtre, da vidim kateri je najbolj uporaben (vidim, da so vsi podobno))
print("Rišem primerjalne grafe ...")
izris.plot_filter_comparison()
#-----primerjava------------

#------ANALIZA VRHOV (R_R_INTERVALOV)---#
print("Analiziram R-R intervale ...")
RR.RRpd()

#------ANALIZA HRV IN BPM---------------#
print("Analiziram srčni utrip in variabilnost")
HRVBPM.hrvbpm()
